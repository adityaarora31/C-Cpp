#include<iostream>
#include "graphics.h"
#define MAXARR 10
using namespace std;

class Shapes
{


public:
int x,y,z;
  Shapes();
void classbar(int,int,int,int);
void circle();
};

Shapes::Shapes()
{
  x=200;
  y=250;
  z=300;
}
void Shapes::classbar(int xc,int yc ,int a ,int zc )
{
  bar(xc,yc,a,zc);
}

int main(int argc, char *argv[])
{
  int gdriver,gmode;
  int items,i;
  static int tx=200,bx=250,by=300;
  int itemvalues[MAXARR];
  int dppoints[14] = {200, 150, 300, 250, 400, 150, 425, 350, 300, 275, 150, 350, 200, 150};
  int fppoints[14] = {500, 150, 600, 250, 700, 150, 725, 350, 600, 275, 450, 350, 500, 150};
  gdriver = VGA;
  gmode=VGAMAX;
  Shapes obj[MAXARR];
  initgraph(&gdriver,&gmode,NULL);
  printf("Enter the number of items \n");
  scanf("%d", &items);
  printf("Enter the items one by one \n");
  for(i=0;i<items;i++)
  {
    scanf("%d",&itemvalues[i]);
  }


  setcolor(RED);
  setfontcolor(RED);
  outtextxy(2, 180, "Following is the graph \n");

for(i=0;i<items;i++)
{

  obj[i].classbar(tx,itemvalues[i],bx,by);
  
  tx+=50;
  bx+=50;

}


  getch();

  closegraph();
  return (0);
}
