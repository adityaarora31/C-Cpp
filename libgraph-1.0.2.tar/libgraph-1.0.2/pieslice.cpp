#include<iostream>
#include"graphics.h"

using namespace std;

int main(int argc, char *argv[])
{
  int gdriver,gmode;
  int dppoints[14] = {200, 150, 300, 250, 400, 150, 425, 350, 300, 275, 150, 350, 200, 150};
  int fppoints[14] = {500, 150, 600, 250, 700, 150, 725, 350, 600, 275, 450, 350, 500, 150};
  gdriver = VGA;gmode=VGAMAX;
  initgraph(&gdriver,&gmode,"");
  printf("libgraph shapes and colors demo\n");


  pieslice(200, 200, 0, 135, 100);
getch();



  closegraph();
  getch();
  return 0;
}
